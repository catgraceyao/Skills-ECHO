# Echo Protocol 技术架构设计

## 版本: v1.0
## 日期: 2026-03-13
## 架构师: Echo Protocol 技术团队

---

# 一、资产 Schema 设计

## 1.1 核心数据结构 (Solidity)

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title EchoAsset
 * @notice Echo Protocol 核心资产结构
 */
struct EchoAsset {
    // 基础信息
    uint256 tokenId;           // 唯一标识
    address creator;           // 创作者地址
    uint256 createdAt;         // 铸造时间戳
    string metadataURI;        // IPFS/Arweave 上的元数据链接
    
    // 资产内容
    string audioHash;          // 音频文件内容哈希 (IPFS CID)
    uint256 duration;          // 音频时长 (秒)
    string title;              // 作品标题
    string description;        // 作品描述
    
    // 引用关系
    uint256[] parents;         // 引用的父资产 ID 数组 (支持多父引用)
    uint256 version;           // 版本号 (原创=1，每次衍生+1)
    bytes32 derivationType;    // 衍生类型: REMIX / SAMPLE / COVER / EXTEND
    
    // 权属定价 (单位: wei 或自定义代币)
    RightsPricing pricing;
    
    // 状态
    AssetStatus status;        // ACTIVE, FROZEN, BURNED
}

/**
 * @notice 权属定价结构
 */
struct RightsPricing {
    uint256 ownershipPrice;    // 所有权价格 (买断)
    uint256 usagePrice;        // 单次使用权价格
    uint256 derivativePrice;   // 衍生权价格 (获得创建衍生作品的许可)
    uint256 extensionPrice;    // 扩展权价格
}

/**
 * @notice 资产状态枚举
 */
enum AssetStatus {
    ACTIVE,    // 正常可用
    FROZEN,    // 冻结 (争议或创作者主动冻结)
    BURNED     // 已销毁
}
```

## 1.2 引用关系图存储设计

```solidity
/**
 * @notice 引用关系存储优化方案
 * @dev 为了节省 Gas，采用双向指针 + 事件日志的设计
 */
contract EchoRegistry {
    // 正向：资产 -> 它的直接子资产 (用于展示"被谁引用了")
    mapping(uint256 => uint256[]) public children;
    
    // 反向：资产 -> 它的直接父资产 (存储在 EchoAsset.parents 中)
    
    // 缓存：资产 -> 到根的路径哈希 (用于快速验证和分润计算)
    mapping(uint256 => bytes32) public lineageHash;
    
    // 全局衍生树根节点列表 (原创资产)
    uint256[] public originalAssets;
    
    // 事件：引用关系变更时触发，方便链下索引
    event AssetCreated(uint256 indexed tokenId, address indexed creator, uint256[] parents);
    event AssetDerived(uint256 indexed childId, uint256 indexed parentId, bytes32 derivationType);
}
```

### 引用关系查询优化

由于链上存储昂贵，完整的多层级树遍历不适合在合约中执行。采用**链下计算 + 链上验证**模式：

1. **链下索引器**：监听事件，在链下维护完整的衍生树结构
2. **链上验证**：只需验证直接父资产存在且有效
3. **分润计算**：由链下提交计算结果，链上合约验证路径有效性

```solidity
/**
 * @notice 分润路径证明结构
 * @dev 链下计算好路径后，提交此结构供合约验证
 */
struct LineageProof {
    uint256[] path;            // 从被购买资产到原创者的路径 [child, parent, grandparent, ..., original]
    bytes32[] signatures;      // 各节点的签名 (可选，用于高价值交易)
    uint256 totalDepth;        // 路径深度
}
```

---

# 二、多层级分润算法实现

## 2.1 合约核心逻辑

```solidity
/**
 * @title EchoDistributor
 * @notice 多层级分润核心合约
 */
contract EchoDistributor {
    // 参数 (可治理升级)
    uint256 public platformFeeRate = 1000;      // 10% = 1000/10000
    uint256 public directCreatorRate = 4000;    // 40%
    uint256 public upstreamPoolRate = 5000;     // 50%
    uint256 public originalGuarantee = 2500;    // 25% 原创者保底
    uint256 public decayFactor = 7000;          // 0.7 = 7000/10000
    
    address public platformTreasury;
    
    /**
     * @notice 执行分润
     * @param assetId 被购买的资产 ID
     * @param amount 支付金额
     * @param proof 链下计算好的分润路径证明
     */
    function distribute(
        uint256 assetId, 
        uint256 amount, 
        LineageProof calldata proof
    ) external payable {
        require(msg.value >= amount, "Insufficient payment");
        
        // 1. 平台手续费
        uint256 platformFee = amount * platformFeeRate / 10000;
        payable(platformTreasury).transfer(platformFee);
        
        uint256 netAmount = amount - platformFee;
        
        // 2. 直接创作者分成
        address directCreator = getCreator(assetId);
        uint256 directShare = netAmount * directCreatorRate / 10000;
        payable(directCreator).transfer(directShare);
        
        // 3. 上游分润池
        uint256 upstreamPool = netAmount * upstreamPoolRate / 10000;
        _distributeUpstream(upstreamPool, proof);
        
        emit DistributionCompleted(assetId, amount, proof.path);
    }
    
    /**
     * @notice 上游分润计算 (指数衰减模型)
     */
    function _distributeUpstream(uint256 pool, LineageProof calldata proof) internal {
        uint256 n = proof.path.length - 1; // 上游层级数
        if (n == 0) return; // 原创资产，无上游
        
        // 计算权重总和
        uint256 totalWeight = 0;
        uint256[] memory weights = new uint256[](n);
        
        for (uint256 i = 0; i < n; i++) {
            // weight[i] = decayFactor^i
            weights[i] = _pow(decayFactor, i);
            totalWeight += weights[i];
        }
        
        // 按权重分配
        uint256 originalShare = 0;
        for (uint256 i = 0; i < n; i++) {
            uint256 assetId = proof.path[i + 1]; // path[0]是被购买的资产
            address creator = getCreator(assetId);
            
            uint256 share = pool * weights[i] / totalWeight;
            
            // 原创者保底检查
            if (i == n - 1) { // 最后一个是最原创的
                uint256 minGuarantee = pool * originalGuarantee / 10000;
                if (share < minGuarantee) {
                    // 从其他上游重新分配，确保原创者拿够保底
                    share = minGuarantee;
                }
            }
            
            payable(creator).transfer(share);
        }
    }
    
    function _pow(uint256 base, uint256 exp) internal pure returns (uint256) {
        uint256 result = 10000; // 基数为 1.0
        for (uint256 i = 0; i < exp; i++) {
            result = result * base / 10000;
        }
        return result;
    }
}
```

## 2.2 分润流程图

```
用户支付 100 USDC 购买 Asset D 使用权
│
├─► 平台手续费 10 USDC (10%) ────────────────────────────► 平台国库
│
├─► 净收益池 90 USDC
    │
    ├─► 直接创作者 (Asset D) 36 USDC (40%) ─────────────► David
    │
    └─► 上游分润池 45 USDC (50%)
        │
        ├─► 父级 (Asset C) ──► 指数衰减权重 1.0 ────────► Charlie
        ├─► 祖父级 (Asset B) ──► 权重 0.7 ─────────────► Bob
        └─► 原创者 (Asset A) ──► 权重 0.49 + 保底补足 ─► Alice
```

---

# 三、智能合约架构

## 3.1 合约清单

| 合约 | 职责 | 继承/依赖 |
|------|------|-----------|
| **EchoToken** | ERC-721 资产代币 | OpenZeppelin ERC721Enumerable |
| **EchoRegistry** | 引用关系管理、资产元数据 | EchoToken |
| **EchoDistributor** | 分润逻辑、收益分配 | EchoRegistry |
| **EchoRights** | 权限管理、授权检查 | EchoRegistry |
| **EchoMarket** | 市场交易、定价、撮合 | EchoDistributor, EchoRights |
| **EchoGovernance** | 参数治理、升级控制 | OpenZeppelin Governor |

## 3.2 核心接口定义

```solidity
// IEchoToken.sol
interface IEchoToken {
    function mint(EchoAsset calldata asset) external returns (uint256);
    function derive(uint256 parentId, EchoAsset calldata asset) external returns (uint256);
    function burn(uint256 tokenId) external;
    function getAsset(uint256 tokenId) external view returns (EchoAsset memory);
    function getLineage(uint256 tokenId) external view returns (uint256[] memory);
}

// IEchoMarket.sol
interface IEchoMarket {
    function purchaseUsage(uint256 assetId, uint256 duration) external payable;
    function purchaseDerivativeRight(uint256 assetId) external payable;
    function listAsset(uint256 assetId, RightsPricing calldata pricing) external;
    function delistAsset(uint256 assetId) external;
}

// IEchoDistributor.sol
interface IEchoDistributor {
    function distribute(uint256 assetId, uint256 amount, LineageProof calldata proof) external payable;
    function claimPendingRewards() external;
    function getPendingRewards(address creator) external view returns (uint256);
}
```

---

# 四、存储与部署方案

## 4.1 链上 vs 链下存储

| 数据类型 | 存储位置 | 理由 |
|----------|----------|------|
| 资产所有权 | 链上 (ERC-721) | 核心确权，不可篡改 |
| 引用关系 | 链上 (轻量) + 链下 (完整) | 链上存直接父，链下存完整树 |
| 音频文件 | IPFS/Arweave | 链上存 hash 验证完整性 |
| 元数据 (标题/描述) | IPFS | 节省 Gas，支持富文本 |
| 分润计算结果 | 链上 (验证) + 链下 (计算) | 复杂计算链下做，链上验证 |
| 波形数据 | 链下 | 纯展示用途，无链上必要 |

## 4.2 部署策略 (Sepolia 测试网)

```javascript
// hardhat deployment script
async function main() {
    // 1. 部署 Token 合约
    const EchoToken = await ethers.getContractFactory("EchoToken");
    const token = await EchoToken.deploy("Echo Music Asset", "ECHO");
    await token.deployed();
    
    // 2. 部署 Registry
    const EchoRegistry = await ethers.getContractFactory("EchoRegistry");
    const registry = await EchoRegistry.deploy(token.address);
    
    // 3. 部署 Distributor
    const EchoDistributor = await ethers.getContractFactory("EchoDistributor");
    const distributor = await EchoDistributor.deploy(registry.address);
    
    // 4. 部署 Market
    const EchoMarket = await ethers.getContractFactory("EchoMarket");
    const market = await EchoMarket.deploy(
        token.address,
        registry.address,
        distributor.address
    );
    
    // 5. 设置权限
    await token.setRegistry(registry.address);
    await registry.setDistributor(distributor.address);
    await registry.setMarket(market.address);
    
    console.log("Deployment complete!");
    console.log("Token:", token.address);
    console.log("Registry:", registry.address);
    console.log("Distributor:", distributor.address);
    console.log("Market:", market.address);
}
```

---

# 五、Gas 优化策略

## 5.1 高 Gas 场景及优化

| 场景 | 原方案 Gas 估算 | 优化方案 | 优化后 Gas |
|------|----------------|----------|-----------|
| 铸造原创资产 | ~150k | 使用 clone 模式 | ~80k |
| 衍生作品 (链长 N) | ~200k + N*50k | 链下计算路径，链上只验证直接父 | ~120k |
| 分润分发 (链长 N) | ~100k + N*30k | 批量分发、累积领取模式 | ~80k + N*15k |
| 查询引用树 | N 次 storage read | 链下索引器 + 单次验证 | 1 次 read |

## 5.2 关键优化技巧

1. **使用 Merkle Tree 验证长链引用**
   - 链下构建完整的引用树 Merkle Root
   - 链上只需验证 Merkle Proof，O(logN) 复杂度

2. **累积收益模式**
   - 不每次交易都分发，而是记录应得份额
   - 创作者主动调用 `claim()` 领取，节省大部分交易的 Gas

3. **打包交易**
   - 批量铸造、批量购买，均摊固定成本

---

# 六、技术白皮书 (面向开发者)

## 6.1 协议定位

Echo Protocol 是一个面向数字创作领域的**产权分离协议**。通过将资产的所有权、使用权、衍生权、扩展权解耦，配合多层级自动分润机制，实现创作生态的可持续激励。

## 6.2 核心创新点

1. **引用图谱上链**：首创将创作引用关系原生记录在区块链上，形成不可篡改的衍生树
2. **多层级自动分润**：链上自动执行指数衰减分润，确保原创者在长尾引用中持续获益
3. **权属颗粒化**：支持使用权、衍生权等细分权利的独立定价和交易

## 6.3 技术选型理由

- **EVM 兼容链**：开发者生态成熟，用户钱包普及度高
- **ERC-721 扩展**：兼容现有 NFT 基础设施 (市场、钱包、索引器)
- **IPFS/Arweave**：去中心化存储，与区块链的不可篡改特性一致
- **链下计算+链上验证**：在可验证性和 Gas 成本之间取得平衡

## 6.4 接入指南

```javascript
// 示例：第三方开发者接入 Echo Protocol
const echo = new EchoSDK({
    provider: window.ethereum,
    network: 'sepolia'
});

// 铸造原创资产
const asset = await echo.mint({
    audioFile: file,
    title: "My Song",
    pricing: {
        usage: ethers.utils.parseEther("0.01"),
        derivative: ethers.utils.parseEther("0.1")
    }
});

// 引用他人作品创作
const remix = await echo.derive({
    parentId: 123,
    audioFile: remixFile,
    title: "Remix of My Song",
    derivationType: "REMIX"
});

// 查询资产的引用链
const lineage = await echo.getLineage(remix.tokenId);
// 返回: [123, 456, 789] (从近到远的引用链)
```

---

**文档版本**: v1.0  
**最后更新**: 2026-03-13  
**维护者**: Echo Protocol 核心团队
